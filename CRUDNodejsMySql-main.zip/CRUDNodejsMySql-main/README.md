# CRUD Node.js MySQL Handlebars

CRUD with javascript, nodejs, and mysql 8. List of tasks with javascript, where we can add tasks, visualize them in a table, edit the tasks and delete them. It is a simple application where we can learn the basic concepts to make more complex applications with javascript.

CRUD con javascript, nodejs, y mysql 8. Lista de tareas con javascript, donde podemos añadir tareas, visualizarlas en una tabla, editar las tareas y eliminarlas. Es una aplicación sencilla donde podemos aprender los conceptos básicos para realizar aplicaciones más complejas con javascript.

CRUD avec javascript, nodejs, et mysql 8. liste de tâches avec javascript, où nous pouvons ajouter des tâches, les visualiser dans un tableau, éditer les tâches et les supprimer. C'est une application simple où nous pouvons apprendre les concepts de base pour faire des applications plus complexes avec javascript.
